from flask_app import app
from flask import render_template, redirect, request, session
from flask_app.models import user, recipe # import entire file, rather than class, to avoid circular imports

# Create Users Controller
@app.route('/recipes/create', methods =['POST'])
def create_recipe():
    if recipe.Recipe.create_recipe(request.form):
        return redirect('/recipes')
    return redirect('/recipes/new')

# Read Users Controller

@app.route('/recipes')
def user_page():
    if 'user_id' not in session:
        return redirect('/')
    data = {'id' : session['user_id']}
    if not user:
        return redirect('/')
    return render_template('recipes.html', user = user.User.get_user_by_id(data), recipes = recipe.Recipe.get_all_recipes_and_users())
    

@app.route('/recipes/new')
def new_recipe_page():
    if 'user_id' not in session:
        return redirect('/')
    return render_template('new_recipe.html')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/recipes/<int:recipe_id>')
def show_recipe(recipe_id):
    if 'user_id' not in session:
        return redirect('/')
    return render_template('recipe_page.html', recipe=recipe.Recipe.get_recipe_by_id_and_user(recipe_id))

# Update Users Controller
@app.route('/recipes/edit/<int:recipe_id>', methods=['POST', 'GET'])
def edit_recipe(recipe_id):
    if 'user_id' not in session:
            return redirect('/')
    if request.method == 'GET':
        return render_template('edit_recipe.html', recipe = recipe.Recipe.get_recipe_by_id(recipe_id))
    if recipe.Recipe.update(request.form):
        return redirect('/recipes')
    return redirect(f'/recipes/edit/{recipe_id}')


# Delete Users Controller
@app.route('/recipes/delete/<int:recipe_id>')
def delete(recipe_id):
    if 'user_id' not in session:
            return redirect('/')
    data = {'id' : recipe_id}
    user.User.delete(data)
    return redirect('/recipes')

# Notes:
# 1 - Use meaningful names
# 2 - Do not overwrite function names
# 3 - No matchy, no worky
# 4 - Use consistent naming conventions 
# 5 - Keep it clean
# 6 - Test every little line before progressing
# 7 - READ ERROR MESSAGES!!!!!!
# 8 - Error messages are found in the browser and terminal




# How to use path variables:
# @app.route('/<int:id>')
# def index(id):
#     user_info = user.User.get_user_by_id(id)
#     return render_template('index.html', user_info)

# Converter -	Description
# string -	Accepts any text without a slash (the default).
# int -	Accepts integers.
# float -	Like int but for floating point values.
# path 	-Like string but accepts slashes.
