
from flask_app import app
from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash, session
from flask_app.models import user
import re
from flask_bcrypt import Bcrypt
bcrypt = Bcrypt(app)
# The above is used when we do login registration, be sure to install flask-bcrypt: pipenv install flask-bcrypt

class Recipe:
    db = "recipes_schema" #which database are you using for this project
    def __init__(self, data):
        self.id = data['id']
        self.name = data['name']
        self.under = data['under']
        self.description = data['description']
        self.instructions = data['instructions']
        self.date_made = data['date_made']
        self.user_id = data['user_id']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.creator = None
        # What changes need to be made above for this project?
        #What needs to be added her for class association?

    @classmethod
    def create_recipe(cls, data):
        print(data)
        if not cls.validate_recipe(data):
            return False
        query = """
        INSERT INTO recipes (name, under, description, instructions, date_made, user_id)
        VALUES (%(name)s, %(under)s, %(description)s, %(instructions)s, %(date_made)s, %(user_id)s);
        """
        recipe_id = connectToMySQL(cls.db).query_db(query, data)
        return recipe_id

    @classmethod
    def get_all_recipes(cls):
        query = """
        SELECT *
        FROM recipes;
        """
        results = connectToMySQL(cls.db).query_db(query)
        all_recipes = []
        for row in results:
            all_recipes.append(cls(row))
        return all_recipes
    
    @classmethod
    def get_all_recipes_and_users(cls):
        query = """
        SELECT * 
        FROM recipes
        JOIN users on recipes.user_id = users.id;
        """
        recipe_info = connectToMySQL(cls.db).query_db(query)
        users_recipes = []
        for row in recipe_info:
            this_recipe = cls(row)
            user_data = {
                'id' : row['users.id'],
                'first_name' : row['first_name'],
                'last_name' : row['last_name'],
                'email' : row['email'],
                'password' : '',
                'created_at' : row['users.created_at'],
                'updated_at' : row['users.updated_at']
            }
            this_recipe.creator = user.User(user_data)
            users_recipes.append(this_recipe)
        return users_recipes
    
    @classmethod
    def get_recipe_by_id(cls, recipe_id):
        query = """
        SELECT * FROM recipes
        WHERE id = %(id)s
        ; """
        results = connectToMySQL(cls.db).query_db(query, {'id':recipe_id})
        return cls(results[0])
    
    @classmethod
    def get_recipe_by_id_and_user(cls, recipe_id):
        query = """
        SELECT *
        FROM recipes
        JOIN users ON recipes.user_id = users.id
        WHERE recipes.id = %(id)s;
        """
        results = connectToMySQL(cls.db).query_db(query, {'id':recipe_id})
        row = results[0]
        this_recipe = cls(row)
        user_data = {
            'id' : row['users.id'],
            'first_name' : row['first_name'],
            'last_name' : row['last_name'],
            'email' : row['email'],
            'password' : '',
            'created_at' : row['users.created_at'],
            'updated_at' : row['users.updated_at']
        }
        this_recipe.creator = user.User(user_data)
        return this_recipe
    
    @classmethod
    def update(cls, data):
        if not cls.validate_recipe(data):
            return False
        query = """
        UPDATE recipes 
        SET name=%(name)s, under=%(under)s, description=%(description)s, instructions=%(instructions)s, date_made=%(date_made)s, updated_at=NOW()
        WHERE id = %(id)s;
        """
        connectToMySQL(cls.db).query_db(query, data)
        return True
        
            
    
        
    
    @staticmethod
    def validate_recipe(data):
        is_valid = True
        if len(data['name']) == 0:
            flash("All fields are required!")
            is_valid = False
        elif len(data['name']) < 3:
            flash("Recipe name must be at least 3 characters.")
            is_valid = False
        if len(data['description']) == 0:
            flash("All fields are required!")
            is_valid = False
        elif len(data['description']) < 3:
            flash("Description must be at least 3 characters.")
            is_valid = False
        if len(data['instructions']) == 0:
            flash("All fields are required!")
            is_valid = False
        elif len(data['instructions']) < 3:
            flash("Instructions must be at least 3 characters.")
            is_valid = False
        if data['date_made'] == "":
            flash("Date is required, please enter one")
            is_valid = False
        if 'under' not in data:
            flash('Cook time is required')
            is_valid = False
        return is_valid

