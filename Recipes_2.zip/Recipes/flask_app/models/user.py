
from flask_app import app
from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash, session
import re
from flask_bcrypt import Bcrypt
from flask_app.models import recipe
bcrypt = Bcrypt(app)
# The above is used when we do login registration, be sure to install flask-bcrypt: pipenv install flask-bcrypt


class User:
    db = "recipes_schema" #which database are you using for this project
    def __init__(self, data):
        if 'users.id' in data:
            self.id = data['users.id']
            self.created_at = data['users.created_at']
            self.updated_at = data['users.updated_at']
        else:
            self.id = data['id']
            self.created_at = data['created_at']
            self.updated_at = data['updated_at']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.email = data['email']
        self.password = data['password']
        
        self.all_recipes = []
        
        # What changes need to be made above for this project?
        #What needs to be added her for class association?



    # Create Users Models
    @classmethod
    def create_user(cls, user_info):
        if not cls.validate_user(user_info):
            return False
        user_info = cls.parse_user_data(user_info)
        query = """
        INSERT INTO users (first_name, last_name, email, password)
        VALUES (%(first_name)s, %(last_name)s, %(email)s, %(password)s);
        """
        user_id = connectToMySQL(cls.db).query_db(query, user_info)
        session['user_id'] = user_id
        session['user_name'] = f'{user_info["first_name"]} {user_info["last_name"]}'
        return user_id
        


    # Read Users Models
    
    @classmethod
    def get_user_by_id(cls, data):
        query = """
        SELECT *
        FROM users
        WHERE id = %(id)s;
        """
        user_data = connectToMySQL(cls.db).query_db(query, data)
        if user_data:
            return cls(user_data[0])
        return False
    
    @classmethod
    def get_user_by_email(cls, email):
        data = {'email': email}
        query = """
        SELECT *
        FROM users
        WHERE email = %(email)s;
        """
        user_data = connectToMySQL(cls.db).query_db(query, data)
        if user_data:
            return cls(user_data[0])
        return False
    
    @classmethod
    def get_user_with_recipes(cls, user_id):
        query = """
        SELECT * FROM users
        JOIN recipes ON recipes.user_id = users.id
        WHERE users.id = %(id)s;
        """
        results = connectToMySQL(cls.db).query_db(query, {'id' : user_id})
        user = cls(results[0])
        for row in results:
            recipe_data = {
                'id': row['recipes.id'],
                'name': row['name'],
                'under': row['under'],
                'description' : row['description'],
                'instructions' : row['instructions'],
                'date_made' : row['date_made'],
                'user_id' : row['user_id'],
                'created_at': row['recipes.created_at'],
                'updated_at': row['recipes.updated_at']
            }
            user.all_recipes.append(recipe.Recipe(recipe_data))
        return user
            
    
    
    @staticmethod
    def login(data):
        this_user = User.get_user_by_email(data['email'])
        if this_user: 
            if bcrypt.check_password_hash(this_user.password, data['password']):
                session['user_id'] = this_user.id
                session['user_name'] = f'{this_user.first_name}'
                return True
        flash("Your login email or password was wrong")
        return False


    
    
    


    # Update Users Models



    # Delete Users Models

    @classmethod
    def delete(cls, data):
        query = """
        DELETE FROM recipes
        WHERE id = %(id)s;
        """
        return connectToMySQL(cls.db).query_db(query, data)

    
    @staticmethod
    def validate_user(data):
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        is_valid = True
        if len(data['first_name']) == 0:
            flash("All fields are required!")
            is_valid = False
        elif len(data['first_name']) < 2:
            flash("Name must be at least 2 characters.")
            is_valid = False
        if len(data['last_name']) == 0:
            flash("All fields are required!")
            is_valid = False
        elif len(data['last_name']) < 2:
            flash("Name must be at least 2 characters.")
            is_valid = False
        if not EMAIL_REGEX.match(data['email']):
            flash("Please use a valid email address.")
            is_valid = False
        if len(data['password']) < 8:
            flash("Your password must be at least 8 characters long.")
            is_valid = False
        if data['password'] != data['confirm_password']:
            flash("Passwords don't match")
            is_valid = False
        if User.get_user_by_email(data['email']):
            flash("That email is taken.")
            is_valid = False
        return is_valid
    
    @staticmethod
    def parse_user_data(data):
        parsed_data = {
            'first_name' : data['first_name'],
            'last_name' : data['last_name'],
            'email' : data['email'],
            'password' : bcrypt.generate_password_hash(data['password'])
        }
        return(parsed_data)