from flask_app import app
from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash, session
# import re
# from flask_bcrypt import Bcrypt
# bcrypt = Bcrypt(app)
# The above is used when we do login registration, be sure to install flask-bcrypt: pipenv install flask-bcrypt


class Ninja:
    db = "dojo_ninjas"
    def __init__(self, data):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.age = data['age']
        self.dojo_id = data['dojo_id']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        
    @classmethod
    def create_ninja(cls,data):
        query = """INSERT INTO ninjas (first_name, last_name, age, dojo_id)
        VALUES (%(first_name)s, %(last_name)s, %(age)s,%(dojo_id)s);
        """
        return connectToMySQL(cls.db).query_db(query,data)
    @classmethod
    def get_one_ninja(cls, id):
        query = """
        SELECT * FROM ninjas
        WHERE id = %(id)s
        ; """
        result = connectToMySQL(cls.db).query_db(query, {'id': id})
        
        return cls(result[0])
    
    @classmethod
    def update(cls, data):
        query = """UPDATE ninjas SET first_name=%(first_name)s, last_name=%(last_name)s, age=%(age)s, updated_at=NOW()
        WHERE id = %(id)s;
        """
        return connectToMySQL(cls.db).query_db(query, data)
    
    @classmethod
    def delete(cls, id):
        query = """
        DELETE FROM ninjas
        WHERE id = %(id)s;
        """
        return connectToMySQL(cls.db).query_db(query, {'id': id})