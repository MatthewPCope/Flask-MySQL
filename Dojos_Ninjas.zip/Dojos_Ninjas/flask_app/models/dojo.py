
from flask_app import app
from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash, session
from flask_app.models import ninja
# import re
# from flask_bcrypt import Bcrypt
# bcrypt = Bcrypt(app)
# The above is used when we do login registration, be sure to install flask-bcrypt: pipenv install flask-bcrypt


class Dojos:
    db = "dojo_ninjas" #which database are you using for this project
    def __init__(self, data):
        self.id = data['id']
        self.name = data['name']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        
        self.all_ninjas = []

    @classmethod
    def create_dojo(cls, data):
        query = """INSERT INTO dojos (name)
        VALUES (%(name)s)
        """
        return connectToMySQL(cls.db).query_db(query,data)
    
    @classmethod
    def get_dojo_by_id(cls, dojo_id):
        query= """
        SELECT *
        FROM dojos
        WHERE id = %(id)s
        """
        data = { 'id' : dojo_id }
        result= connectToMySQL(cls.db).query_db(query,data)
        return cls(result[0])
    
    @classmethod
    def get_all_dojos(cls):
        query = """
        SELECT * 
        FROM dojos;
        """
        results = connectToMySQL(cls.db).query_db(query)
        all_dojos = []
        for dojo in results:
            all_dojos.append(cls(dojo))
        return all_dojos
    
    @classmethod
    def get_dojo_ninja(cls, id):
        query = """
        SELECT * FROM dojos
        LEFT JOIN ninjas ON ninjas.dojo_id = dojos.id
        WHERE dojos.id = %(id)s;
        """
        data = {'id' : id}
        results = connectToMySQL(cls.db).query_db(query, data)
        dojo = cls(results[0])
        for row in results:
            ninja_data = {
                'id': row['ninjas.id'],
                'first_name': row['first_name'],
                'last_name': row['last_name'],
                'age': row['age'],
                'dojo_id' : row['dojo_id'],
                'created_at': row['ninjas.created_at'],
                'updated_at': row['ninjas.updated_at']
            }
            dojo.all_ninjas.append(ninja.Ninja(ninja_data))
            
        return dojo
        # What changes need to be made above for this project?
        #What needs to be added her for class association?



    # Create Users Models



    # Read Users Models



    # Update Users Models



    # Delete Users Models