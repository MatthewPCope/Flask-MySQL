
from flask_app import app
from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash, session
# import re
# from flask_bcrypt import Bcrypt
# bcrypt = Bcrypt(app)
# The above is used when we do login registration, be sure to install flask-bcrypt: pipenv install flask-bcrypt


class User:
    db = "users" #which database are you using for this project
    def __init__(self, data):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.email = data['email']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        # What changes need to be made above for this project?
        #What needs to be added her for class association?
    def full_name(self):
        return f'{self.first_name} {self.last_name}'

    @staticmethod
    def validate_user(user):
        is_valid = True
        if len(user['first_name']) < 2:
            flash("First name is must be at least 3 characters.")
            is_valid = False
        if len(user['last_name']) < 2:
            flash("Last name must be at least 3 characters.")
            is_valid= False
        if len(user['email']) < 3:
            flash("Invalid email format")
            is_valid = False
        return is_valid
    




    # Create Users Models
    @classmethod 
    def create_user(cls, data):
            query = """INSERT INTO Users (first_name, last_name, email)
                    VALUES (%(first_name)s, %(last_name)s, %(email)s);"""
            result = connectToMySQL('users').query_db(query,data)
            return result  


    # Read Users Models
    @classmethod
    def get_all(cls):
        query = "SELECT * FROM Users;"
        results = connectToMySQL('users').query_db(query)
        users = []
        for i in results:
            users.append(cls(i))
        return users

    @classmethod
    def get_user_by_id(cls, data):
        query = "SELECT * FROM users WHERE id = %(id)s"
        result = connectToMySQL('users').query_db(query, data)
        return cls(result[0])

    # Update Users Models
    @classmethod
    def update(cls, data):
        query = """UPDATE users SET first_name=%(first_name)s, last_name=%(last_name)s, email=%(email)s, updated_at=NOW()
        WHERE id = %(id)s;
        """
        return connectToMySQL('users').query_db(query, data)


    # Delete Users Models
    @classmethod
    def delete(cls, data):
        query = """
        DELETE FROM users
        WHERE id = %(id)s;
        """
        return connectToMySQL('users').query_db(query, data)