from flask_app import app
from flask import render_template, redirect, request, session
from flask_app.models import user # import entire file, rather than class, to avoid circular imports

# Create Users Controller

@app.route('/create', methods=['POST'])
def create():
    if not user.User.validate_user(request.form):
        return redirect('/')
    user.User.create_user(request.form)
    session ['first_name'] = request.form['first_name']
    session ['last_name'] = request.form['last_name']
    session ['email'] = request.form['email']
    return redirect('/users')


# Read Users Controller
@app.route('/users')
def users():
    all_users = user.User.get_all()
    return render_template('table.html', users = all_users)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/user/edit/<int:id>')
def edit(id):
    data = {'id' : id}
    return render_template('edit_user.html', user= user.User.get_user_by_id(data))

@app.route('/user/update', methods=['POST'])
def update():
    user.User.update(request.form)
    return redirect('/users')

@app.route('/user/show/<int:id>')
def show(id):
    data = {'id' : id}
    return render_template('show_user.html', user = user.User.get_user_by_id(data))



# Update Users Controller



# Delete Users Controller
@app.route('/user/delete/<int:id>')
def delete(id):
    data = {'id' : id}
    user.User.delete(data)
    return redirect('/users')

# Notes:
# 1 - Use meaningful names
# 2 - Do not overwrite function names
# 3 - No matchy, no worky
# 4 - Use consistent naming conventions 
# 5 - Keep it clean
# 6 - Test every little line before progressing
# 7 - READ ERROR MESSAGES!!!!!!
# 8 - Error messages are found in the browser and terminal




# How to use path variables:
# @app.route('/<int:id>')
# def index(id):
#     user_info = user.User.get_user_by_id(id)
#     return render_template('index.html', user_info)

# Converter -	Description
# string -	Accepts any text without a slash (the default).
# int -	Accepts integers.
# float -	Like int but for floating point values.
# path 	-Like string but accepts slashes.